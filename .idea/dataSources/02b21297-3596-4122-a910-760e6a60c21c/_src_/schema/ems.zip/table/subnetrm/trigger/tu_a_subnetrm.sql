CREATE TRIGGER tu_a_subnetrm
AFTER UPDATE ON subnetrm
FOR EACH ROW
  begin
     declare vResChangeID int;
		
		  insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('topo_mainview_symbol','subnet','symbol_id',SUBSTRING_INDEX(old.dn,':',-1),old.subnetName,concat('子网修改名称:',new.subnetName),3,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();

		  if ifnull(old.subnetName,'')<>ifnull(new.subnetName,'') then
		           insert into `ems_h`.res_log_property (RES_CHANGE_ID,CHANGE_PROPERTY_FIELD,NEW_VALUE,OLD_VALUE,CHANGE_TIME)
		              values(vResChangeID,'symbol_name',new.subnetName,old.subnetName,date_format(NOW(),'%Y-%m-%d %T'));
		  end if; 
		  
     insert INTO `ems_h`.`topo_mainview_symbol_log` 
 (`id`,`oper_type`,`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`,`c_date`) 
  select  
    vResChangeID,3,SUBSTRING_INDEX(aimDn,':',-1), new.subnetName, '1', 'SUBNET', SUBSTRING_INDEX(aimDn,':',-1), 
   NULL, '0', '0', '2', '0',
  '1', '1', '0', x_dimension, y_dimension, 
   '1', '2', '2', '0', '0', '0',
   concat(',0',SUBSTRING_INDEX(aimDn,':',-1),','), '1_1_1', NULL, '0', '1',
      NULL, 'admin', old.description,date_format(NOW(),'%Y-%m-%d %T')
   from subnetviewrm
   where aimDn=old.dn;
		  
		  
		  
end;
