CREATE TRIGGER td_a_oltequiprm
AFTER DELETE ON oltequiprm
FOR EACH ROW
  begin
  declare vResChangeID int;
	
	
		 insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('ne','ne','ne_id',SUBSTRING_INDEX(old.dn,':',-1),old.Name,'',2,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();

    insert INTO `ems_h`.`ne_log` 
  (`id`,`oper_type`,`subnet_id`, `ne_id`, `ne_type_id`, `ne_name`, `ne_friendly_name`,
  `software_ver`, `hardware_ver`, `ipaddress`, `macaddress`, `subnet_mask`, 
  `snmp_port`, `snmp_readcommon`, `snmp_writecommon`, `snmp_v3_para`, `snmp_version`, `snmp_retry`, `snmp_timeout`, 
  `login_user`, `login_password`, `create_user`, `create_time`, `update_user`, `update_time`, 
  `init_status`, `syn_status`, `last_syn_time`, `syn_end_time`, `syn_remark`, `hierarchy`, `remark`, 
  `online_status`, `latitude`, `longitude`, `emscontainer_id`,`c_date`) 
 values(  
   vResChangeID,2,SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',old.subnetIdList),',',-2),',',1), SUBSTRING_INDEX(old.dn,':',-1), old.DeviceType, old.Name, old.Name,
   NULL, NULL,old.QxIpAddr, old.QxMacAddr, old.QxIpMask, 
   old.QxTCPPort, old.SnmpGetCommunity, old.SnmpSetCommunity, NULL, '2', '1', '3', 
   NULL, NULL, 'admin', NULL, NULL, NULL, 
   '2', '2', NULL, NULL, NULL, '', NULL, 
   '1', '0', '0', '1',date_format(NOW(),'%Y-%m-%d %T'));

 
 
 		 insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('topo_mainview_symbol','ne','symbol_id',500000+SUBSTRING_INDEX(old.dn,':',-1),old.Name,'删除网元',2,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();
		        
    insert INTO `ems_h`.`topo_mainview_symbol_log` 
 (`id`,`oper_type`,`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`,`c_date`) 
  values(
     vResChangeID,2,500000+SUBSTRING_INDEX(old.dn,':',-1),old.Name, '1', 'NE', SUBSTRING_INDEX(old.dn,':',-1),
   SUBSTRING_INDEX(old.dn,':',-1), SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',old.subnetIdList),',',-2),',',1), SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',old.subnetIdList),',',-2),',',1), '3', '2', 
   '1', '1', '0', 0, 0,
    '1', '2', '2', '0', '0','0',
     concat(',0',old.subnetIdList,500000+SUBSTRING_INDEX(old.dn,':',-1),','), concat('2_',old.DeviceType), NULL, '0', '1', 
     NULL, 'admin', NULL,date_format(NOW(),'%Y-%m-%d %T') );
  if(old.DEVICETYPE = 907 or old.DEVICETYPE = 914) then
  	delete from ems_h.pm_threshold_value_config where NE_ID =  SUBSTRING_INDEX(old.dn,':',-1); 
        delete from ems_h.pm_task_detail where NE_ID =  SUBSTRING_INDEX(old.dn,':',-1); 
  end if;
end;
