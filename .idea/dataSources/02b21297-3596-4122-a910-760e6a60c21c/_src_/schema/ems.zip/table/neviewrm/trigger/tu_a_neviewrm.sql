CREATE TRIGGER tu_a_neviewrm
AFTER UPDATE ON neviewrm
FOR EACH ROW
  begin
  declare vResChangeID int;
	declare vName varchar(200);
	
   if instr(old.dn,'CF::FSAP::UserViewRM:32001:')>0 then
     select name into vName from oltequiprm where dn=new.aimDn;
     
     
		  
		  insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('topo_mainview_symbol','ne','symbol_id',500000+SUBSTRING_INDEX(old.aimDn,':',-1),vName,'网元移动位置',3,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();
		        
		  if ifnull(old.x_dimension,'')<>ifnull(new.x_dimension,'') then
		           insert into `ems_h`.res_log_property (RES_CHANGE_ID,CHANGE_PROPERTY_FIELD,NEW_VALUE,OLD_VALUE,CHANGE_TIME)
		              values(vResChangeID,'x',new.x_dimension,old.x_dimension,date_format(NOW(),'%Y-%m-%d %T'));
		  end if;
		  if ifnull(old.y_dimension,'')<>ifnull(new.y_dimension,'') then
		           insert into `ems_h`.res_log_property (RES_CHANGE_ID,CHANGE_PROPERTY_FIELD,NEW_VALUE,OLD_VALUE,CHANGE_TIME)
		              values(vResChangeID,'y',new.y_dimension,old.y_dimension,date_format(NOW(),'%Y-%m-%d %T'));
		  end if;
		  
     insert INTO `ems_h`.`topo_mainview_symbol_log` 
 (`id`,`oper_type`,`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`,`c_date`) 
  select 
     vResChangeID,3,500000+SUBSTRING_INDEX(new.aimDn,':',-1),Name, '1', 'NE', SUBSTRING_INDEX(new.aimDn,':',-1),
   SUBSTRING_INDEX(new.aimDn,':',-1), SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',subnetIdList),',',-2),',',1), SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',subnetIdList),',',-2),',',1), '3', '2', 
   '1', '1', '0', new.x_dimension, new.y_dimension,
    '1', '2', '2', '0', '0','0',
     concat(',0',subnetIdList,500000+SUBSTRING_INDEX(new.aimDn,':',-1),','), concat('2_',DeviceType), NULL, '0', '1', 
     NULL, 'admin', NULL,date_format(NOW(),'%Y-%m-%d %T') 
   from oltequiprm where dn=new.aimDn;
		  
		  
   end if;
end;
