CREATE TRIGGER ti_a_alarmmgrrm
AFTER INSERT ON alarmmgrrm
FOR EACH ROW
  begin
	declare vResChangeID int;
  declare vautoID long;

if new.clearTime =0 and new.AffirmState=0 then
		 insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('alarm','alarm','alarm_id',new.alarmId,new.alarmId,'',1,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();

  select count(*) into vautoID from `ems_h`.`alarm_log`  where oper_type=1 and  alarm_id= new.alarmId;
  if vautoID=0 then 
  insert INTO `ems_h`.`alarm_log` 
(`id`,`oper_type`,`alarm_id`, `ne_id`, `ne_name`, `ne_type_id`, `ne_type_name`, `ipaddress`, 
`res_type_name`, 
`res_url`, 
`res_name`, 
`alarm_type_id`, `alarm_type_name`, `alarm_type_label`, `alarm_level`, `alarm_event_type`, 
`is_affect_service`, `alarm_category`, `alarm_cause_id`, `alarm_group`, `report_time`,
 `latest_time`, `ne_time`, `lasting_time`, `ack_time`, `ack_user`, `ack_host`, `ack_log`, 
 `clear_time`, `clear_user`, `clear_host`, `clear_log`, `isclr`, `isack`, `trap_msg`, `alarm_remark`,`c_date`)
 select  
 vResChangeID,1,new.alarmId, new.OltId, n.name, n.deviceType, t.ne_type_name,  n.QxIpAddr, 
 CASE new.ponifid WHEN 0 THEN 'ne' ELSE 'port' END, 
 CASE new.ponifid WHEN 0 THEN	concat('/ne=', new.OltId) ELSE concat('/ne=',	new.OltId, '/shelf=1/slot=', new.slotid, '/port=',new.ponifid) END,
 new.alarmSourceName,
 
  new.AlarmType, a.alarm_type_name, a.alarm_type_label, case new.AlarmLevel when 1 then 5 when 2 then 3 when 3 then 2 else new.AlarmLevel end, '2', 
 '0', '1', 'unidentified', NULL, DATE_ADD('1970-1-1',INTERVAL new.GenTime+28800 SECOND) , 
 DATE_ADD('1970-1-1',INTERVAL new.GenTime+28800 SECOND), '', '0', new.AffirmTime, new.UserIdAffirmer, '', '', 
 DATE_ADD('1970-1-1',INTERVAL new.ClearTime+28800 SECOND), new.userIdClear, '', new.ReasonForClear, '0', new.AffirmState, new.autoID, '',date_format(NOW(),'%Y-%m-%d %T')
 from oltequiprm n,`ems_h`.alarm_type a,`ems_h`.ne_type t
 where n.deviceType=t.ne_type_id and new.AlarmType=a.alarm_type_id
  and n.dn =concat('CF::FSAP::OLTEquipRM:',new.OltId);
end if;	

elseif new.clearTime>0 then
 
  select count(*) into vautoID from `ems_h`.`alarm_log`  where oper_type=2 and alarm_id= new.alarmId ;
  if vautoID=0 then 
		 insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('alarm','alarm','alarm_id',new.alarmId,new.alarmId,'',2,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();

  insert INTO `ems_h`.`alarm_log` 
(`id`,`oper_type`,`alarm_id`, `ne_id`, `ne_name`, `ne_type_id`, `ne_type_name`, `ipaddress`, 
`res_type_name`, 
`res_url`, 
`res_name`, 
`alarm_type_id`, `alarm_type_name`, `alarm_type_label`, `alarm_level`, `alarm_event_type`, 
`is_affect_service`, `alarm_category`, `alarm_cause_id`, `alarm_group`, `report_time`,
 `latest_time`, `ne_time`, `lasting_time`, `ack_time`, `ack_user`, `ack_host`, `ack_log`, 
 `clear_time`, `clear_user`, `clear_host`, `clear_log`, `isclr`, `isack`, `trap_msg`, `alarm_remark`,`c_date`)
 select  
 vResChangeID,2,new.alarmId, new.OltId, n.name, n.deviceType, t.ne_type_name,  n.QxIpAddr, 
 CASE new.ponifid WHEN 0 THEN 'ne' ELSE 'port' END, 
 CASE new.ponifid WHEN 0 THEN	concat('/ne=', new.OltId) ELSE concat('/ne=',	new.OltId, '/shelf=1/slot=', new.slotid, '/port=',new.ponifid) END,
 new.alarmSourceName,
 
  new.AlarmType, a.alarm_type_name, a.alarm_type_label, case new.AlarmLevel when 1 then 5 when 2 then 3 when 3 then 2 else new.AlarmLevel end, '2', 
 '0', '1', 'unidentified', NULL, DATE_ADD('1970-1-1',INTERVAL new.GenTime+28800 SECOND) , 
 DATE_ADD('1970-1-1',INTERVAL new.GenTime+28800 SECOND), '', '0', new.AffirmTime, new.UserIdAffirmer, '', '', 
 DATE_ADD('1970-1-1',INTERVAL new.ClearTime+28800 SECOND), new.userIdClear, '', new.ReasonForClear, '1', new.AffirmState, new.autoID, '',date_format(NOW(),'%Y-%m-%d %T')
 from oltequiprm n,`ems_h`.alarm_type a,`ems_h`.ne_type t
 where n.deviceType=t.ne_type_id and new.AlarmType=a.alarm_type_id
  and n.dn =concat('CF::FSAP::OLTEquipRM:',new.OltId);
end if;
	      
 
end if;

end;
