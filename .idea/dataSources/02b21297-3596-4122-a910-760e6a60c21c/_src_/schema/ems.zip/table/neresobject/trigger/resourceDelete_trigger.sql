CREATE TRIGGER resourceDelete_trigger
BEFORE DELETE ON neresobject
FOR EACH ROW
  BEGIN
  DELETE FROM monitordata WHERE neResKey = OLD.neResKey;
END;
