CREATE PROCEDURE Proc_DeleteFluxDataWithOid(IN m_oltid INT)
  BEGIN
	
	delete from dailydata  where oltid=m_oltid;
        delete from weekly  where oltid=m_oltid;
        delete from monthdata  where oltid=m_oltid;
        delete from year  where oltid=m_oltid;
END;
