CREATE PROCEDURE Proc_FluxTest()
  BEGIN
	DECLARE i INT;
	SET i=10000;
	WHILE i>0 DO
	call Proc_InsertFluxData(8,8,8,8,8,8,8,8,10,100);
	SET i=i-1;
	END WHILE;
END;
