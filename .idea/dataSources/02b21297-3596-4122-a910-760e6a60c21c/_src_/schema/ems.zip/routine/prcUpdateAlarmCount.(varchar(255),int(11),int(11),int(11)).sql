CREATE PROCEDURE prcUpdateAlarmCount(IN URL VARCHAR(255), IN alarmLevel INT, IN isAck INT, IN isClr INT)
  BEGIN
	declare ResType varchar(200);
	declare ResID,pResID varchar(255);
	declare vSubnetID int;
	declare vHierarchy varchar(254);
  declare v1,v2,v3,v4,v5  int default 0;
  declare va1,va2,va3,va4,va5 int default 0;
  declare vS,vSa int default 0;
  
  if isClr = 0 and isAck = 0 then
     set vS = 1;
  elseif isClr = 0 and isAck = 1 then
     set vS = -1;
     set vSa= 1;
  elseif isClr = 1 and isAck = 0 then
     set vS = -1;
  elseif isClr = 1 and isAck = 1 then
     set vSa = -1;
  end if;
 
  case alarmLevel
   when 1 then set v1 = vS; set va1 = vSa;
   when 2 then set v2 = vS; set va2 = vSa;
   when 3 then set v3 = vS; set va3 = vSa;
   when 4 then set v4 = vS; set va4 = vSa;
   when 5 then set v5 = vS; set va5 = vSa;
  end case;
  
  
  call `prcGetAlarmRes`(URL,ResType,ResID,PResID);
    
  case lower(ResType)
  when 'port' then
     update port set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1,
                     alarm_status = getAlarmStatus(critical_count + v5,major_count + v4,minor_count + v3, warning_count + v2,indeter_count + v1,critical_count_a + va5,major_count_a + va4,minor_count_a + va3,warning_count_a + va2, indeter_count_a + va1) 
            where port_id=ResID;
  when 'card' then
     update card set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1,
                     alarm_status = getAlarmStatus(critical_count + v5,major_count + v4,minor_count + v3, warning_count + v2,indeter_count + v1,critical_count_a + va5,major_count_a + va4,minor_count_a + va3,warning_count_a + va2, indeter_count_a + va1) 
            where card_id=ResID;
     if instr(ResID,'#remote')>0 then
          update topo_mainview_symbol set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1   
            where res_id=ResID;
     end if;
      
  when 'chassis' then
     update chassis set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1,
                     alarm_status = getAlarmStatus(critical_count + v5,major_count + v4,minor_count + v3, warning_count + v2,indeter_count + v1,critical_count_a + va5,major_count_a + va4,minor_count_a + va3,warning_count_a + va2, indeter_count_a + va1) 
            where chassis_id=ResID;
  when 'ne' then
     update ne set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1,
                     alarm_status = getAlarmStatus(critical_count + v5,major_count + v4,minor_count + v3, warning_count + v2,indeter_count + v1,critical_count_a + va5,major_count_a + va4,minor_count_a + va3,warning_count_a + va2, indeter_count_a + va1) 
            where ne_id=ResID;
     update topo_mainview_symbol set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1,
                     alarm_status = getAlarmStatus(critical_count + v5,major_count + v4,minor_count + v3, warning_count + v2,indeter_count + v1,critical_count_a + va5,major_count_a + va4,minor_count_a + va3,warning_count_a + va2, indeter_count_a + va1) 
            where res_type_name='NE' and res_id=ResID;
            
     select subnet_id into vSubnetID from ne where ne_id = ResID;
     if vSubnetID <> 0 then
         update subnet set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1,
                     alarm_status = getAlarmStatus(critical_count + v5,major_count + v4,minor_count + v3, warning_count + v2,indeter_count + v1,critical_count_a + va5,major_count_a + va4,minor_count_a + va3,warning_count_a + va2, indeter_count_a + va1) 
            where subnet_id=vSubnetID; 
         select map_hierarchy into vHierarchy from topo_mainview_symbol where symbol_id=vSubnetID;    
         update topo_mainview_symbol set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1   
            where instr(vHierarchy,map_hierarchy)=1;
     end if;       
            
  end case;
  
  if lower(ResType) <> 'ne' or lower(ResType)<>'' then
     call prcUpdateAlarmCount(pResID,alarmLevel,isAck,isClr);
  end if;
END;
