CREATE PROCEDURE prc_clearData(INOUT errorcode INT)
  begin

  declare continue HANDLER FOR SQLEXCEPTION set errorcode = -1;
  set errorcode=0;
  truncate table `ems_h`.`alarm_his`;
  truncate table `ems_h`.`alarm`;
  truncate table `ems_h`.`link`;
  truncate table `ems_h`.`port`;
  delete from `ems_h`.`ne`; 
  delete from `ems_h`.`subnet` where subnet_id>0;
  
  delete from `ems_h`.`topo_mainview_link_symbol`;
  delete from `ems_h`.`topo_mainview_symbol` where symbol_id>0;
  
end;
