CREATE PROCEDURE prcDeleteNe(IN NEID INT)
  BEGIN
	declare isExist,iC int default 0; 
	declare vtablename varchar(200);
	declare vsql       varchar(2000);
  
  declare rs cursor for select distinct TABLE_NAMES FROM res_type_cfg where TABLE_NAMES like 'PMDATA_%';
  declare CONTINUE HANDLER FOR NOT FOUND SET isExist = 1; 
	
	delete from alarm where ne_id = NEID;
	delete from alarm_his where ne_id = NEID;
	
	  open rs;
    fetch rs into vtablename;
    while(isExist = 0) do 
      set vsql = concat('delete from ',vtablename ,' where ne_id = ',NEID);
      call exeSql(vsql,iC);
      fetch rs into vtablename;
    end while;
    close rs;
	
	
	delete from pm_task_detail where ne_id = NEID;
		
	delete from link where SRC_IRCNETNODEID = NEID or DES_IRCNETNODEID = NEID;
	
	
	delete from port where ne_id = NEID;
	delete from card where ne_id = NEID;
	delete from slot where ne_id = NEID;
	delete from chassis where ne_id = NEID;
	
	
END;
