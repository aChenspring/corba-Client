CREATE FUNCTION getAlarmStatus(Critical INT, Major INT, Minor INT, Warning INT, Indeter INT, Critical_a INT,
                               Major_a  INT, Minor_a INT, Warning_a INT, Indeter_a INT)
  RETURNS INT
  BEGIN
     if Critical+Critical_a>0 then
             return 5;
     elseif Major+Major_a>0 then
             return 4;
     elseif Minor+Minor_a>0 then
             return 3;
     elseif Warning+Warning_a>0 then
             return 2;
     elseif Indeter+Indeter_a>0 then
             return 1;
     else
             return 0;
     end if;
END;
