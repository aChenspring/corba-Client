CREATE PROCEDURE prcResetAlarmCount()
  BEGIN
	  declare isExist int default 0; 
	  declare vres_url varchar(500);
	  declare valarm_level,visack,visclr int;
	  declare vmaxalarmID int;
    declare rs cursor for 
     select res_url,alarm_level,isack,isclr FROM alarm where alarm_id <= vmaxalarmID order by alarm_id;
  
    declare CONTINUE HANDLER FOR NOT FOUND SET isExist = 1; 
    
     select max(alarm_id) into vmaxalarmID from alarm;
     update port set critical_count = 0,major_count = 0,minor_count = 0,warning_count = 0,indeter_count = 0,critical_count_a = 0,major_count_a = 0,minor_count_a = 0,warning_count_a = 0,indeter_count_a = 0,port_alarm_status = 0;

     update card set critical_count = 0,major_count = 0,minor_count = 0,warning_count = 0,indeter_count = 0,critical_count_a = 0,major_count_a = 0,minor_count_a = 0,warning_count_a = 0,indeter_count_a = 0,card_alarm_status = 0;

     update chassis set critical_count = 0,major_count = 0,minor_count = 0,warning_count = 0,indeter_count = 0,critical_count_a = 0,major_count_a = 0,minor_count_a = 0,warning_count_a = 0,indeter_count_a = 0,chassis_alarm_status = 0;

     update ne set critical_count = 0,major_count = 0,minor_count = 0,warning_count = 0,indeter_count = 0,critical_count_a = 0,major_count_a = 0,minor_count_a = 0,warning_count_a = 0,indeter_count_a = 0,alarm_status = 0;

     update subnet set critical_count = 0,major_count = 0,minor_count = 0,warning_count = 0,indeter_count = 0,critical_count_a = 0,major_count_a = 0,minor_count_a = 0,warning_count_a = 0,indeter_count_a = 0,alarm_status = 0;

     update topo_mainview_symbol set critical_count = 0,major_count = 0,minor_count = 0,warning_count = 0,indeter_count = 0,critical_count_a = 0,major_count_a = 0,minor_count_a = 0,warning_count_a = 0,indeter_count_a = 0,alarm_status = 0;

     drop table if exists alarm_rjs_tmp;
     create table alarm_rjs_tmp as select * from alarm;
     truncate table alarm;
     insert into alarm select * from alarm_rjs_tmp;
  
END;
