CREATE TRIGGER td_b_alarm
BEFORE DELETE ON alarm
FOR EACH ROW
  begin
     declare errCode varchar(200); 
     declare continue handler for sqlexception set errCode='td_b_alarm ERROR';
     insert into alarm_his select * from alarm where alarm_id = old.alarm_id;
     if old.isclr = 0 then
         call prcUpdateAlarmCount(old.res_url,old.alarm_level,old.isack,1);
     end if;
end;
