CREATE TRIGGER tu_b_subnet
BEFORE UPDATE ON subnet
FOR EACH ROW
  begin
	 declare vhierarchy,phierarchy varchar(254);
   declare v1,v2,v3,v4,v5  int default 0;
   declare va1,va2,va3,va4,va5 int default 0;
   
   
   if new.p_subnet_id<>old.p_subnet_id then
        select map_hierarchy into vhierarchy from topo_mainview_symbol where symbol_id=new.subnet_id;   
        select map_hierarchy into phierarchy from topo_mainview_symbol where symbol_id=new.p_subnet_id;
 
        update topo_mainview_symbol set map_parent_id=new.p_subnet_id,tree_parent_id=new.p_subnet_id where symbol_id=new.subnet_id; 
        update topo_mainview_symbol set map_hierarchy = replace(map_hierarchy,vhierarchy,concat(phierarchy,new.subnet_id,','))
            where map_hierarchy like concat(vhierarchy,'%');
        
        
        select critical_count,major_count,minor_count,warning_count,indeter_count,critical_count_a,major_count_a,minor_count_a,warning_count_a,indeter_count_a
            into v5,v4,v3,v2,v1,va5,va4,va3,va2,va1 
            from topo_mainview_symbol where symbol_id=new.subnet_id;

        update topo_mainview_symbol set critical_count = critical_count - v5,major_count = major_count - v4,minor_count = minor_count - v3,warning_count = warning_count - v2,indeter_count = indeter_count - v1,critical_count_a = critical_count_a - va5,major_count_a = major_count_a - va4,minor_count_a = minor_count_a - va3,warning_count_a = warning_count_a - va2,indeter_count_a = indeter_count_a - va1   
            where instr(vhierarchy,map_hierarchy)=1 and map_hierarchy <> vhierarchy  and symbol_id <>0;
        update topo_mainview_symbol set critical_count = critical_count + v5,major_count = major_count + v4,minor_count = minor_count + v3,warning_count = warning_count + v2,indeter_count = indeter_count + v1,critical_count_a = critical_count_a + va5,major_count_a = major_count_a + va4,minor_count_a = minor_count_a + va3,warning_count_a = warning_count_a + va2,indeter_count_a = indeter_count_a + va1   
            where instr(phierarchy,map_hierarchy)=1 and symbol_id <>0;

   end if;
end;
