CREATE TRIGGER ti_b_subnet
BEFORE INSERT ON subnet
FOR EACH ROW
  begin
   declare psubnet_hierarchy varchar(254);
   if new.p_subnet_id<> -1 then
        select subnet_hierarchy into psubnet_hierarchy from subnet where subnet_id=new.p_subnet_id;
        set new.subnet_hierarchy=concat(psubnet_hierarchy,new.subnet_id,',');
     

   end if;
end;
