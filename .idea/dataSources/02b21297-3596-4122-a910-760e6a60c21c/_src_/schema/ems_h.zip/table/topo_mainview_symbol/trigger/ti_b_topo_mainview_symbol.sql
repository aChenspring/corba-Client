CREATE TRIGGER ti_b_topo_mainview_symbol
BEFORE INSERT ON topo_mainview_symbol
FOR EACH ROW
  begin
   declare pmap_hierarchy varchar(254);
   if new.map_parent_id<> -1 then
        select map_hierarchy into pmap_hierarchy from topo_mainview_symbol where symbol_id=new.map_parent_id;
        set new.map_hierarchy=concat(pmap_hierarchy,new.symbol_id,',');
     
        
   end if;
end;
