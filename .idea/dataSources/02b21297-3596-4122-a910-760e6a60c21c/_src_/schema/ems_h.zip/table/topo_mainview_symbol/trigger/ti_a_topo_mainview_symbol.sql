CREATE TRIGGER ti_a_topo_mainview_symbol
AFTER INSERT ON topo_mainview_symbol
FOR EACH ROW
  begin
	if new.res_type_name='SUBNET' and new.symbol_id<>0 then
	 insert into subnet (subnet_id,subnet_type_id,subnet_name,p_subnet_id,
                       subnet_layout,create_user,create_time,remark)
          values(new.symbol_id,new.topo_type_id,new.symbol_name,new.map_parent_id,
                 new.layout,new.create_user,now(),new.remark);
  end if;
end;
