CREATE TRIGGER tu_a_topo_mainview_symbol
AFTER UPDATE ON topo_mainview_symbol
FOR EACH ROW
  begin
	if new.res_type_name='SUBNET' and new.symbol_id<>0 then
      if new.topo_type_id <> old.topo_type_id then
         update subnet set subnet_type_id = new.topo_type_id where subnet_id=new.symbol_id;  
      end if;
      if new.symbol_name <> old.symbol_name then
         update subnet set subnet_name = new.symbol_name where subnet_id=new.symbol_id;  
      end if;
      if new.remark <> old.remark then
         update subnet set remark = new.remark where subnet_id=new.symbol_id;  
      end if;
  end if;
end;
