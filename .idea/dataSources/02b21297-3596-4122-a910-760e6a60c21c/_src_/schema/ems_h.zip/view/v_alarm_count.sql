CREATE VIEW v_alarm_count AS
  SELECT
    count(`ems_h`.`alarm`.`alarm_id`) AS `alarm_count`,
    `ems_h`.`alarm`.`alarm_level`     AS `ALARM_LEVEL`
  FROM `ems_h`.`alarm`
  GROUP BY `ems_h`.`alarm`.`alarm_level`;
