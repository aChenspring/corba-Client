CREATE VIEW v_ne_type AS
  SELECT
    `ems_h`.`ne_type`.`ne_type_id`         AS `ne_type_id`,
    `ems_h`.`ne_type`.`ne_type_name`       AS `ne_type_name`,
    `ems_h`.`ne_type`.`ne_map_icon`        AS `ne_map_icon`,
    `ems_h`.`ne_type`.`ne_tree_icon`       AS `ne_tree_icon`,
    `ems_h`.`ne_type`.`ems_type_id`        AS `ems_type_id`,
    `ems_h`.`ne_type`.`emsbean_id`         AS `emsbean_id`,
    `ems_h`.`ne_type`.`ne_oid`             AS `ne_oid`,
    `ems_h`.`ne_type`.`mib_index`          AS `mib_index`,
    `ems_h`.`ne_type`.`panel_id`           AS `panel_id`,
    `ems_h`.`ne_type`.`isvalid`            AS `isvalid`,
    `ems_h`.`ne_type`.`ne_type_remark`     AS `ne_type_remark`,
    `ems_h`.`ne_type`.`ne_device_img`      AS `ne_device_img`,
    `ems_h`.`ne_type`.`ne_popup_module_id` AS `ne_popup_module_id`,
    `ems_h`.`ems_bean`.`EMSCON_ID`         AS `EMSCON_ID`,
    `ems_h`.`ems_bean`.`EMSBEAN_USER`      AS `EMSBEAN_USER`,
    `ems_h`.`ems_bean`.`EMSBEAN_PASSWORD`  AS `EMSBEAN_PASSWORD`,
    `ems_h`.`ems_bean`.`MAX_NE_COUNT`      AS `MAX_NE_COUNT`,
    `ems_h`.`ems_bean`.`NE_MAX_TASK_COUNT` AS `NE_MAX_TASK_COUNT`,
    `ems_h`.`ems_bean`.`IF_CONFIG_FILE`    AS `IF_CONFIG_FILE`,
    `ems_h`.`ems_bean`.`EMSBEAN_CLASS`     AS `EMSBEAN_CLASS`
  FROM `ems_h`.`ne_type`
    JOIN `ems_h`.`ems_bean`
  WHERE (`ems_h`.`ems_bean`.`EMSBEAN_ID` = `ems_h`.`ne_type`.`emsbean_id`);
