CREATE VIEW v_chassis AS
  SELECT
    `ems_h`.`ne`.`ne_type_id`                  AS `ne_type_id`,
    `ems_h`.`ne`.`ne_name`                     AS `ne_name`,
    `ems_h`.`ne`.`ne_friendly_name`            AS `ne_friendly_name`,
    `ems_h`.`chassis`.`chassis_id`             AS `chassis_id`,
    `ems_h`.`chassis`.`ne_id`                  AS `ne_id`,
    `ems_h`.`chassis`.`chassis_type_id`        AS `chassis_type_id`,
    `ems_h`.`chassis`.`chassis_name`           AS `chassis_name`,
    `ems_h`.`chassis`.`chassis_friendly_name`  AS `chassis_friendly_name`,
    `ems_h`.`chassis`.`chassis_index`          AS `chassis_index`,
    `ems_h`.`chassis`.`chassis_working_status` AS `chassis_working_status`,
    `ems_h`.`chassis`.`chassis_online_status`  AS `chassis_online_status`,
    `ems_h`.`chassis`.`temperature`            AS `temperature`,
    `ems_h`.`chassis`.`chassis_serial`         AS `chassis_serial`,
    `ems_h`.`chassis`.`total_slot_num`         AS `total_slot_num`,
    `ems_h`.`chassis`.`empty_slot_num`         AS `empty_slot_num`,
    `ems_h`.`chassis`.`is_visible`             AS `is_visible`,
    `ems_h`.`chassis`.`create_user`            AS `create_user`,
    `ems_h`.`chassis`.`create_time`            AS `create_time`,
    `ems_h`.`chassis`.`update_user`            AS `update_user`,
    `ems_h`.`chassis`.`update_time`            AS `update_time`,
    `ems_h`.`chassis`.`chassis_remark`         AS `chassis_remark`,
    `ems_h`.`chassis`.`chassis_alarm_status`   AS `chassis_alarm_status`,
    `ems_h`.`chassis`.`critical_count`         AS `critical_count`,
    `ems_h`.`chassis`.`major_count`            AS `major_count`,
    `ems_h`.`chassis`.`minor_count`            AS `minor_count`,
    `ems_h`.`chassis`.`warning_count`          AS `warning_count`,
    `ems_h`.`chassis`.`indeter_count`          AS `indeter_count`,
    `ems_h`.`chassis`.`critical_count_a`       AS `critical_count_a`,
    `ems_h`.`chassis`.`major_count_a`          AS `major_count_a`,
    `ems_h`.`chassis`.`minor_count_a`          AS `minor_count_a`,
    `ems_h`.`chassis`.`warning_count_a`        AS `warning_count_a`,
    `ems_h`.`chassis`.`indeter_count_a`        AS `indeter_count_a`,
    `ems_h`.`chassis_type`.`chassis_type_name` AS `chassis_type_name`,
    `ems_h`.`chassis_type`.`chassis_icon`      AS `chassis_icon`,
    `ems_h`.`chassis_type`.`mib_index`         AS `mib_index`
  FROM `ems_h`.`ne`
    JOIN `ems_h`.`chassis`
    JOIN `ems_h`.`chassis_type`
  WHERE ((`ems_h`.`ne`.`ne_id` = `ems_h`.`chassis`.`ne_id`) AND
         (`ems_h`.`chassis`.`chassis_type_id` = `ems_h`.`chassis_type`.`chassis_type_id`));
