CREATE VIEW v_slot AS
  SELECT
    `ems_h`.`ne`.`ne_type_id`           AS `ne_type_id`,
    `ems_h`.`ne`.`ne_name`              AS `ne_name`,
    `ems_h`.`ne`.`ne_friendly_name`     AS `ne_friendly_name`,
    `ems_h`.`slot`.`slot_id`            AS `slot_id`,
    `ems_h`.`slot`.`ne_id`              AS `ne_id`,
    `ems_h`.`slot`.`chassis_id`         AS `chassis_id`,
    `ems_h`.`slot`.`slot_index`         AS `slot_index`,
    `ems_h`.`slot`.`slot_name`          AS `slot_name`,
    `ems_h`.`slot`.`slot_friendly_name` AS `slot_friendly_name`,
    `ems_h`.`slot`.`serial`             AS `serial`,
    `ems_h`.`slot`.`is_used`            AS `is_used`,
    `ems_h`.`slot`.`is_visible`         AS `is_visible`,
    `ems_h`.`slot`.`create_user`        AS `create_user`,
    `ems_h`.`slot`.`create_time`        AS `create_time`,
    `ems_h`.`slot`.`update_user`        AS `update_user`,
    `ems_h`.`slot`.`update_time`        AS `update_time`,
    `ems_h`.`slot`.`slot_remark`        AS `slot_remark`
  FROM `ems_h`.`ne`
    JOIN `ems_h`.`slot`
  WHERE (`ems_h`.`ne`.`ne_id` = `ems_h`.`slot`.`ne_id`);
