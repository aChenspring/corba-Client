CREATE VIEW v_topo_type AS
  SELECT
    `a`.`TOPO_TYPE_ID`       AS `TOPO_TYPE_ID`,
    `a`.`MAIN_VIEW_ID`       AS `MAIN_VIEW_ID`,
    `a`.`PARENT_ID`          AS `PARENT_ID`,
    `a`.`TYPE_CATEGORY`      AS `TYPE_CATEGORY`,
    `a`.`TREE_ICON_PATH`     AS `TREE_ICON_PATH`,
    `a`.`MAP_ICON_PATH`      AS `MAP_ICON_PATH`,
    `a`.`DISPLAY_NAME`       AS `DISPLAY_NAME`,
    `a`.`RES_TYPE_NAME`      AS `RES_TYPE_NAME`,
    `a`.`EXPROPERTIES`       AS `EXPROPERTIES`,
    `a`.`IS_VALID`           AS `IS_VALID`,
    `a`.`DEVICE_TYPE`        AS `DEVICE_TYPE`,
    `a`.`IS_LEAF`            AS `IS_LEAF`,
    `a`.`PANEL_ID`           AS `PANEL_ID`,
    `b`.`ADD_PANEL_CLASS`    AS `ADD_PANEL_CLASS`,
    `b`.`MODIFY_PANEL_CLASS` AS `MODIFY_PANEL_CLASS`,
    `b`.`PANEL_TYPE`         AS `PANEL_TYPE`,
    `a`.`IS_GATEWAY`         AS `IS_GATEWAY`
  FROM (`ems_h`.`topo_type` `a` LEFT JOIN `ems_h`.`topo_operator_panel` `b` ON ((`a`.`PANEL_ID` = `b`.`PANEL_ID`)))
  UNION SELECT
          concat('2_', `c`.`ne_type_id`) AS `TOPO_TYPE_ID`,
          1                              AS `MAIN_VIEW_ID`,
          '2'                            AS `PARENT_ID`,
          2                              AS `TYPE_CATEGORY`,
          `c`.`ne_tree_icon`             AS `TREE_ICON_PATH`,
          `c`.`ne_map_icon`              AS `MAP_ICON_PATH`,
          `c`.`ne_type_name`             AS `DISPLAY_NAME`,
          'NE'                           AS `RES_TYPE_NAME`,
          ''                             AS `EXPROPERTIES`,
          `c`.`isvalid`                  AS `IS_VALID`,
          `c`.`ne_type_id`               AS `DEVICE_TYPE`,
          1                              AS `IS_LEAF`,
          `c`.`panel_id`                 AS `PANEL_ID`,
          `e`.`ADD_PANEL_CLASS`          AS `ADD_PANEL_CLASS`,
          `e`.`MODIFY_PANEL_CLASS`       AS `MODIFY_PANEL_CLASS`,
          `e`.`PANEL_TYPE`               AS `PANEL_TYPE`,
          0                              AS `IS_GATEWAY`
        FROM (`ems_h`.`ne_type` `c` LEFT JOIN `ems_h`.`topo_operator_panel` `e` ON ((`c`.`panel_id` = `e`.`PANEL_ID`)));
