CREATE VIEW pmdata_dt_if_stat_view AS
  SELECT
    `max_if_stat`.`NE_ID`                                                                                                                                 AS `NE_ID`,
    `max_if_stat`.`RES_NAME`                                                                                                                              AS `RES_NAME`,
    `max_if_stat`.`COLLECT_YEAR`                                                                                                                          AS `COLLECT_YEAR`,
    `max_if_stat`.`COLLECT_MONTH`                                                                                                                         AS `COLLECT_MONTH`,
    `max_if_stat`.`COLLECT_WEEK`                                                                                                                          AS `COLLECT_WEEK`,
    `max_if_stat`.`COLLECT_HOUR`                                                                                                                          AS `COLLECT_HOUR`,
    `max_if_stat`.`COLLECT_DAY`                                                                                                                           AS `COLLECT_DAY`,
    `max_if_stat`.`COLLECT_15MIN`                                                                                                                         AS `COLLECT_15MIN`,
    `max_if_stat`.`PERIOD`                                                                                                                                AS `PERIOD`,
    `max_if_stat`.`CARD_ID`                                                                                                                               AS `CARD_ID`,
    `max_if_stat`.`OBJ_INSTANCE`                                                                                                                          AS `OBJ_INSTANCE`,
    `max_if_stat`.`COLLECT_TIME`                                                                                                                          AS `COLLECT_TIME`,
    `max_if_stat`.`OBJ_URL`                                                                                                                               AS `OBJ_URL`,
    `max_if_stat`.`ifindex`                                                                                                                               AS `ifindex`,
    `max_if_stat`.`ifDescr`                                                                                                                               AS `ifDescr`,
    `max_if_stat`.`hmIfaceUtilization`                                                                                                                    AS `hmIfaceUtilization`,
    ((`max_if_stat`.`ifInUcastPkts` - `min_if_stat`.`ifInUcastPkts`) / (SELECT
                                                                          (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                           time_to_sec(
                                                                               `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                           AS `ifInUcastPkts`,
    ((`max_if_stat`.`ifInNUcastPkts` - `min_if_stat`.`ifInNUcastPkts`) / (SELECT
                                                                            (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                             time_to_sec(
                                                                                 `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                         AS `ifInNUcastPkts`,
    if(((`max_if_stat`.`ifInOctets` + 0) >= (`min_if_stat`.`ifInOctets` + 0)),
       (((`max_if_stat`.`ifInOctets` - `min_if_stat`.`ifInOctets`) * 8) / (SELECT
                                                                             (time_to_sec(`max_if_stat`.`COLLECT_TIME`)
                                                                              - time_to_sec(
                                                                                  `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`)),
       ((((4294967295 - `max_if_stat`.`ifInOctets`) + `min_if_stat`.`ifInOctets`) * 8) / (SELECT (time_to_sec(
                                                                                                      `max_if_stat`.`COLLECT_TIME`)
                                                                                                  - time_to_sec(
                                                                                                      `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`)))   AS `ifInOctets`,
    ((`max_if_stat`.`ifInDiscards` - `min_if_stat`.`ifInDiscards`) / (SELECT
                                                                        (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                         time_to_sec(
                                                                             `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                             AS `ifInDiscards`,
    ((`max_if_stat`.`ifInErrors` - `min_if_stat`.`ifInErrors`) / (SELECT (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                          time_to_sec(
                                                                              `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                            AS `ifInErrors`,
    ((`max_if_stat`.`ifOutUcastPkts` - `min_if_stat`.`ifOutUcastPkts`) / (SELECT
                                                                            (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                             time_to_sec(
                                                                                 `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                         AS `ifOutUcastPkts`,
    ((`max_if_stat`.`ifOutNUcastPkts` - `min_if_stat`.`ifOutNUcastPkts`) / (SELECT
                                                                              (time_to_sec(`max_if_stat`.`COLLECT_TIME`)
                                                                               - time_to_sec(
                                                                                   `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                       AS `ifOutNUcastPkts`,
    if(((`max_if_stat`.`ifOutOctets` + 0) >= (`min_if_stat`.`ifOutOctets` + 0)),
       (((`max_if_stat`.`ifOutOctets` - `min_if_stat`.`ifOutOctets`) * 8) / (SELECT (time_to_sec(
                                                                                         `max_if_stat`.`COLLECT_TIME`) -
                                                                                     time_to_sec(
                                                                                         `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`)),
       ((((4294967295 - `max_if_stat`.`ifOutOctets`) + `min_if_stat`.`ifOutOctets`) * 8) / (SELECT (time_to_sec(
                                                                                                        `max_if_stat`.`COLLECT_TIME`)
                                                                                                    - time_to_sec(
                                                                                                        `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))) AS `ifOutOctets`,
    ((`max_if_stat`.`ifOutDiscards` - `min_if_stat`.`ifOutDiscards`) / (SELECT
                                                                          (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                           time_to_sec(
                                                                               `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                           AS `ifOutDiscards`,
    ((`max_if_stat`.`ifOutErrors` - `min_if_stat`.`ifOutErrors`) / (SELECT (time_to_sec(`max_if_stat`.`COLLECT_TIME`) -
                                                                            time_to_sec(
                                                                                `min_if_stat`.`COLLECT_TIME`)) AS `dif_second`))                          AS `ifOutErrors`
  FROM (`ems_h`.`pmdata_dt_if_stat` `max_if_stat`
    JOIN `ems_h`.`pmdata_dt_if_stat_last` `min_if_stat`)
  WHERE
    ((`max_if_stat`.`NE_ID` = `min_if_stat`.`NE_ID`) AND (`max_if_stat`.`OBJ_INSTANCE` = `min_if_stat`.`OBJ_INSTANCE`));
