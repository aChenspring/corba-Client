CREATE VIEW v_pm_task_list AS
  SELECT
    group_concat(`ems_h`.`pm_task_detail`.`TASK_ID` SEPARATOR ',') AS `TASK_LIST`,
    `ems_h`.`pm_task_detail`.`NE_ID`                               AS `NE_ID`
  FROM `ems_h`.`pm_task_detail`
  GROUP BY `ems_h`.`pm_task_detail`.`NE_ID`;
