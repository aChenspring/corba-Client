CREATE VIEW v_card_type AS
  SELECT
    `ems_h`.`card_type`.`ne_type_id`      AS `ne_type_id`,
    `ems_h`.`card_type`.`card_type_id`    AS `card_type_id`,
    `ems_h`.`card_type`.`card_type_name`  AS `card_type_name`,
    `ems_h`.`card_type`.`card_map_icon`   AS `card_map_icon`,
    `ems_h`.`card_type`.`card_tree_icon`  AS `card_tree_icon`,
    `ems_h`.`card_type`.`is_local`        AS `is_local`,
    `ems_h`.`card_type`.`port_count`      AS `port_count`,
    `ems_h`.`card_type`.`card_des`        AS `card_des`,
    `ems_h`.`card_type`.`occupy_slot_num` AS `occupy_slot_num`,
    `ems_h`.`card_type`.`mib_index`       AS `mib_index`,
    `ems_h`.`card_type`.`card_type_desc`  AS `card_type_desc`,
    `ne_type`.`ne_type_name`              AS `ne_type_name`,
    `ne_type`.`ne_map_icon`               AS `ne_map_icon`,
    `ne_type`.`ne_tree_icon`              AS `ne_tree_icon`,
    `ne_type`.`ems_type_id`               AS `ems_type_id`,
    `ne_type`.`emsbean_id`                AS `emsbean_id`,
    `ne_type`.`ne_oid`                    AS `ne_oid`,
    `ne_type`.`mib_index`                 AS `ne_mib_index`,
    `ne_type`.`ne_type_remark`            AS `ne_type_remark`,
    `ne_type`.`panel_id`                  AS `panel_id`,
    `ne_type`.`isvalid`                   AS `isvalid`,
    `ne_type`.`EMSCON_ID`                 AS `EMSCON_ID`,
    `ne_type`.`EMSBEAN_USER`              AS `EMSBEAN_USER`,
    `ne_type`.`EMSBEAN_PASSWORD`          AS `EMSBEAN_PASSWORD`,
    `ne_type`.`MAX_NE_COUNT`              AS `MAX_NE_COUNT`,
    `ne_type`.`NE_MAX_TASK_COUNT`         AS `NE_MAX_TASK_COUNT`,
    `ne_type`.`IF_CONFIG_FILE`            AS `IF_CONFIG_FILE`,
    `ne_type`.`EMSBEAN_CLASS`             AS `EMSBEAN_CLASS`
  FROM `ems_h`.`card_type`
    JOIN `ems_h`.`v_ne_type` `ne_type`
  WHERE (`ems_h`.`card_type`.`ne_type_id` = `ne_type`.`ne_type_id`);
