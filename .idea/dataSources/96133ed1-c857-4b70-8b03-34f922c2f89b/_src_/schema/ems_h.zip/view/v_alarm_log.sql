CREATE VIEW v_alarm_log AS
  SELECT
    `t`.`RES_CHANGE_ID`         AS `RES_CHANGE_ID`,
    `t`.`RES_TYPE_TABLE`        AS `RES_TYPE_TABLE`,
    `t`.`RES_TYPE`              AS `RES_TYPE`,
    `t`.`RES_PK_FIELDS`         AS `RES_PK_FIELDS`,
    `t`.`RES_IDS`               AS `RES_IDS`,
    `t`.`LOG_RES_NAME`          AS `LOG_RES_NAME`,
    `t`.`LOG_REMARK`            AS `LOG_REMARK`,
    `t`.`CHANGE_TYPE`           AS `CHANGE_TYPE`,
    `t`.`CHANGE_TIME`           AS `CHANGE_TIME`,
    `a`.`id`                    AS `id`,
    `a`.`oper_type`             AS `oper_type`,
    `a`.`alarm_id`              AS `alarm_id`,
    `a`.`ne_id`                 AS `ne_id`,
    `a`.`ne_name`               AS `ne_name`,
    `a`.`ne_type_id`            AS `ne_type_id`,
    `a`.`ne_type_name`          AS `ne_type_name`,
    `a`.`ipaddress`             AS `ipaddress`,
    `a`.`res_type_name`         AS `res_type_name`,
    `a`.`res_url`               AS `res_url`,
    `a`.`res_name`              AS `res_name`,
    `a`.`alarm_type_id`         AS `alarm_type_id`,
    `a`.`alarm_type_name`       AS `alarm_type_name`,
    `a`.`alarm_type_label`      AS `alarm_type_label`,
    `a`.`alarm_level`           AS `alarm_level`,
    `a`.`alarm_event_type`      AS `alarm_event_type`,
    `a`.`is_affect_service`     AS `is_affect_service`,
    `a`.`alarm_category`        AS `alarm_category`,
    `a`.`alarm_cause_id`        AS `alarm_cause_id`,
    `a`.`alarm_group`           AS `alarm_group`,
    `a`.`report_time`           AS `report_time`,
    `a`.`latest_time`           AS `latest_time`,
    `a`.`ne_time`               AS `ne_time`,
    `a`.`lasting_time`          AS `lasting_time`,
    `a`.`ack_time`              AS `ack_time`,
    `a`.`ack_user`              AS `ack_user`,
    `a`.`ack_host`              AS `ack_host`,
    `a`.`ack_log`               AS `ack_log`,
    `a`.`clear_time`            AS `clear_time`,
    `a`.`clear_user`            AS `clear_user`,
    `a`.`clear_host`            AS `clear_host`,
    `a`.`clear_log`             AS `clear_log`,
    `a`.`isclr`                 AS `isclr`,
    `a`.`isack`                 AS `isack`,
    `a`.`trap_msg`              AS `trap_msg`,
    `a`.`alarm_remark`          AS `alarm_remark`,
    `a`.`c_date`                AS `c_date`,
    (CASE `a`.`clear_time`
     WHEN '0'
       THEN ''
     WHEN '1970-01-01 08:00:00'
       THEN ''
     ELSE `a`.`clear_time` END) AS `cleartime`
  FROM `ems_h`.`res_log_total` `t`
    JOIN `ems_h`.`alarm_log` `a`
  WHERE ((`t`.`RES_TYPE_TABLE` = 'alarm') AND (`t`.`CHANGE_TYPE` IN (1, 2)) AND (`t`.`RES_CHANGE_ID` = `a`.`id`));
