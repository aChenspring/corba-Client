CREATE VIEW v_pm_task_detail AS
  SELECT
    `pt`.`COLLECT_RES_TYPE`        AS `COLLECT_RES_TYPE`,
    `pt`.`COLLECT_TYPE_NAME`       AS `COLLECT_TYPE_NAME`,
    `pt`.`NE_TYPE_ID`              AS `NE_TYPE_ID`,
    `pt`.`RES_TYPE`                AS `RES_TYPE`,
    `pt`.`INDEX_ADDTION`           AS `INDEX_ADDTION`,
    `pd`.`TASK_ID`                 AS `TASK_ID`,
    `pd`.`NE_ID`                   AS `NE_ID`,
    `pd`.`RES_ID`                  AS `RES_ID`,
    `pd`.`RES_INDEX`               AS `RES_INDEX`,
    `pd`.`RES_NAME`                AS `RES_NAME`,
    `pd`.`COLLECT_TYPE_ID`         AS `COLLECT_TYPE_ID`,
    `pd`.`LAST_COLLECT_TIME`       AS `LAST_COLLECT_TIME`,
    `pd`.`LAST_COLLECT_ERROR_CODE` AS `LAST_COLLECT_ERROR_CODE`
  FROM (`ems_h`.`pm_task_detail` `pd`
    JOIN `ems_h`.`pm_collect_type` `pt`)
  WHERE (`pd`.`COLLECT_TYPE_ID` = `pt`.`COLLECT_TYPE_ID`);
