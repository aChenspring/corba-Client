CREATE TRIGGER tu_a_alarm
AFTER UPDATE ON alarm
FOR EACH ROW
  begin
     declare errCode varchar(200); 
     declare continue handler for sqlexception set errCode='tu_a_alarm ERROR';
     if new.isack <> old.isack or new.isclr <> old.isclr then
       call prcUpdateAlarmCount(new.res_url,new.alarm_level,new.isack,new.isclr);
     end if;
end;
