CREATE TRIGGER td_a_topo_mainview_symbol
AFTER DELETE ON topo_mainview_symbol
FOR EACH ROW
  begin
	if old.res_type_name='SUBNET' and old.symbol_id<>0 then
	   delete from subnet where subnet_id=old.symbol_id;
  end if;
  delete from topo_mainview_link_symbol 
     where src_symbol_id=old.symbol_id or dest_symbol_id=old.symbol_id; 
  
end;
