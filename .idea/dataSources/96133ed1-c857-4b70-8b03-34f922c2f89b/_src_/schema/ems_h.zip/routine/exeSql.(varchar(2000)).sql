CREATE PROCEDURE exeSql(IN strSql VARCHAR(2000), OUT RowCout INT)
  BEGIN
      DECLARE continue HANDLER FOR SQLEXCEPTION set RowCout = -1;
      begin
       set @StrSql := strSql;
       prepare stmt from @StrSql; 
       execute stmt;
       set RowCout = ROW_COUNT();
       deallocate prepare stmt;
      end;
END;
