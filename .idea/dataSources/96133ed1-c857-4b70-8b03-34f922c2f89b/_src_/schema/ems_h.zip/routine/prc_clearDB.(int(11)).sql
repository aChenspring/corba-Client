CREATE PROCEDURE prc_clearDB(INOUT errorcode INT)
  begin

  declare continue HANDLER FOR SQLEXCEPTION set errorcode = -1;
  set errorcode=0;
  
  call prc_clearData(errorcode);

truncate table `ems_h`.res_log_total;
truncate table `ems_h`.res_log_property;
truncate table `ems_h`.topo_mainview_symbol_log;
truncate table `ems_h`.topo_mainview_link_symbol_log;
truncate table `ems_h`.alarm_log;
truncate table `ems_h`.subnet_log;
truncate table `ems_h`.ne_log;
truncate table `ems_h`.port_log;
truncate table `ems_h`.link_log;

truncate table `ems_h`.topo_mainview_symbol_h;
truncate table `ems_h`.topo_mainview_link_symbol_h;
truncate table `ems_h`.alarm_h;
truncate table `ems_h`.subnet_h;
truncate table `ems_h`.ne_h;
truncate table `ems_h`.port_h;
truncate table `ems_h`.link_h;
               
end;
