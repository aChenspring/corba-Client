CREATE PROCEDURE prc_deleteHisData()
  BEGIN
  DECLARE errorcode INT;
  DECLARE vDate VARCHAR(30);
  DECLARE vDays INT(11);
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET errorcode = -1;
  SET errorcode=0;
  SELECT saveDays INTO vDays FROM playbackconfig;
  
  SET vDate =DATE_FORMAT(DATE_ADD(NOW(),INTERVAL -vDays DAY),'%Y-%m-%d');
  
  DELETE FROM `ems_h`.`alarm_h` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`link_h` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`port_h` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`ne_h` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`subnet_h` WHERE  c_date<vDate;
  DELETE FROM `ems_h`.`topo_mainview_link_symbol_h` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`topo_mainview_symbol_h` WHERE c_date<vDate;
  
  
  DELETE FROM `ems_h`.res_log_total WHERE change_time<vDate;
  DELETE FROM `ems_h`.res_log_property WHERE change_time<vDate;
  DELETE FROM `ems_h`.`alarm_log` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`link_log` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`port_log` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`ne_log` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`subnet_log` WHERE  c_date<vDate;
  DELETE FROM `ems_h`.`topo_mainview_link_symbol_log` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`topo_mainview_symbol_log` WHERE c_date<vDate;
  DELETE FROM `ems_h`.`pm_task_detail` WHERE LAST_COLLECT_TIME<vDate;  
  DELETE FROM `ems_h`.`sysloghistory` WHERE GENERATETIME<vDate;

END;
