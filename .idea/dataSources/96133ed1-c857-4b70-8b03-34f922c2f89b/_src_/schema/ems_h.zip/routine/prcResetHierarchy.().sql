CREATE PROCEDURE prcResetHierarchy()
  BEGIN
	DECLARE vC INT DEFAULT 0;

	DROP TABLE if EXISTS topo_mainview_symbol_bak;
  create table topo_mainview_symbol_bak as select * from topo_mainview_symbol;

	SELECT COUNT(*) INTO vC FROM information_schema.`COLUMNS` WHERE TABLE_NAME = 'topo_mainview_symbol' AND COLUMN_NAME = 'flag';
	IF (vC > 0) THEN
		UPDATE topo_mainview_symbol SET FLAG = NULL;
  ELSE
    alter table topo_mainview_symbol add COLUMN flag int DEFAULT NULL;
	END IF;

  UPDATE topo_mainview_symbol SET MAP_HIERARCHY = ',0,',FLAG = 1 WHERE SYMBOL_ID = 0;
  set vC = 1;
	WHILE(vC > 0) DO
		UPDATE topo_mainview_symbol s1,topo_mainview_symbol s2 set s1.MAP_HIERARCHY = CONCAT(s2.MAP_HIERARCHY,s1.SYMBOL_ID,','),s1.flag = 1 where s1.flag is NULL and s2.flag = 1 and s1.MAP_PARENT_ID = s2.SYMBOL_ID;
		select count(*) into vC from topo_mainview_symbol where FLAG is null;
	End While;

	alter table topo_mainview_symbol DROP COLUMN flag;
END;
