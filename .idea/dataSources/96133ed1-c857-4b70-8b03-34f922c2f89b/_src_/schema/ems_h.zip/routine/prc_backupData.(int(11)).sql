CREATE PROCEDURE prc_backupData(INOUT errorcode INT)
  begin
  declare continue HANDLER FOR SQLEXCEPTION set errorcode = -1;
 
  set errorcode=0;
  insert INTO `ems_h`.`subnet_h` (`subnet_id`, `subnet_type_id`, `subnet_name`, `p_subnet_id`, `subnet_layout`, `subnet_icon`, `subnet_hierarchy`, `create_user`, `create_time`, `update_user`, `update_time`, `remark`,  `x`, `y`,`c_date`) 
  select  
        SUBSTRING_INDEX(t2.dn,':',-1), '1_1_1',subnetName , '0', '0', NULL, ',0,', NULL, NULL, NULL, NULL, description, x_dimension, y_dimension, date_format(NOW(),'%Y-%m-%d')
  from `ems`.subnetviewrm t1,`ems`.subnetrm t2 
       where t1.dn like 'CF::FSAP::UserViewRM:32001:%' and t1.aimDn=t2.dn;

  insert INTO `ems_h`.`topo_mainview_symbol_h` 
 (`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`,`c_date`) 
  select 
   SUBSTRING_INDEX(aimDn,':',-1), subnetName, '1', 'SUBNET', SUBSTRING_INDEX(aimDn,':',-1), 
   NULL, '0', '0', '2', '0',
  '1', '1', '0', x_dimension, y_dimension, 
   '1', '2', '2', '0', '0', '0',
   concat(',0',SUBSTRING_INDEX(aimDn,':',-1),','), '1_1_1', NULL, '0', '1',
      NULL, 'admin', description,date_format(NOW(),'%Y-%m-%d')
  from `ems`.subnetviewrm t1,`ems`.subnetrm t2 
       where t1.dn like 'CF::FSAP::UserViewRM:32001:%' and t1.aimDn=t2.dn;


  insert INTO `ems_h`.`ne_h` 
(`subnet_id`, `ne_id`, `ne_type_id`, `ne_name`, `ne_friendly_name`,
 `software_ver`, `hardware_ver`, `ipaddress`, `macaddress`, `subnet_mask`, 
`snmp_port`, `snmp_readcommon`, `snmp_writecommon`, `snmp_v3_para`, `snmp_version`, `snmp_retry`, `snmp_timeout`, 
`login_user`, `login_password`, `create_user`, `create_time`, `update_user`, `update_time`, 
`init_status`, `syn_status`, `last_syn_time`, `syn_end_time`, `syn_remark`, `hierarchy`, `remark`, 
`online_status`, `latitude`, `longitude`, `emscontainer_id`,`c_date`)  
  select  
SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',subnetIdList),',',-2),',',1), SUBSTRING_INDEX(dn,':',-1), DeviceType, Name, Name,
 NULL, NULL,QxIpAddr, QxMacAddr, QxIpMask, 
QxTCPPort, SnmpGetCommunity, SnmpSetCommunity, NULL, '2', '1', '3', 
NULL, NULL, 'admin', NULL, NULL, NULL, 
'2', '2', NULL, NULL, NULL, '', NULL, 
'1', '0', '0', '1',date_format(NOW(),'%Y-%m-%d')
  from `ems`.oltequiprm;
 

     insert INTO `ems_h`.`topo_mainview_symbol_h` 
 (`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`,`c_date`) 
  select 
     500000+SUBSTRING_INDEX(aimDn,':',-1),Name, '1', 'NE', SUBSTRING_INDEX(aimDn,':',-1),
   SUBSTRING_INDEX(aimDn,':',-1), SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',subnetIdList),',',-2),',',1), SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',subnetIdList),',',-2),',',1), '3', '2', 
   '1', '1', '0', x_dimension, y_dimension,
    '1', '2', '2', '0', '0','0',
     concat(',0',subnetIdList,500000+SUBSTRING_INDEX(aimDn,':',-1),','), concat('2_',t1.DeviceType), NULL, '0', '1', 
     NULL, 'admin', NULL,date_format(NOW(),'%Y-%m-%d') 
   from `ems`.oltequiprm t1,`ems`.neviewrm t2
    where t1.dn=t2.aimDn and t2.dn like 'CF::FSAP::UserViewRM:32001:%';


    insert INTO `ems_h`.`link_h` 
(`LINK_ID`, `LINK_NAME`, `FRIENDLY_NAME`, 
`SRC_PORT_ID`, `SRC_PORT_TYPE`, `DES_PORT_ID`, `DES_PORT_TYPE`,
 `LINE_RATE`, `LINE_LENGTH`, `TRAN_MODEL`, 
 `SRC_IRCNETNODEID`,`SRC_RES_TYPE`, `SRC_ID`, `DES_IRCNETNODEID`, `DES_RES_TYPE`, `DES_ID`,
 `REMARK`, `IS_PROTECTED`, `RATE_TIMES`, `LINK_TYPE_ID`, `LINK_DIRECTION`, `ATTENUATION`, 
`INDEX_IN_MIB`, `LINK_STATE`, `ACTIVE_STATE`, `CREATE_USER`, `CREATE_TIME`, 
`MAINTENANCE_PERSON_ID`, `TOPO_TYPE_ID`, `CREATE_TYPE`, `LINK_URL`, `ISLINK_AUTO_DISCOVER`,`c_date`) 
select  
   odnLinkId, concat(EastPortName,'---',WestPortName), concat(EastPortName,'---',WestPortName),
   replace(replace(replace(EastPortDn,'CF::FSAP::OLTEquipRM:','/ne='),':SubrackRM:1:SlotRM:','/shelf=1/slot='),':PhyPortRM:','/port='), 'PORT', 
   replace(replace(replace(WestPortDn,'CF::FSAP::OLTEquipRM:','/ne='),':SubrackRM:1:SlotRM:','/shelf=1/slot='),':PhyPortRM:','/port='),  'PORT', 
   '13', '1', '1', 
   arraysplit(EastPortDn,':',6),  '', '', arraysplit(WestPortDn,':',6), '', '', 
   NULL, '2', '1', '1',   '2', '0', 
   NULL, '1', '1', NULL, NULL, NULL, '16', '0', NULL, '2',date_format(NOW(),'%Y-%m-%d') 
   from `ems`.odnlinkrm;

  insert INTO `ems_h`.`alarm_h` 
(`alarm_id`, `ne_id`, `ne_name`, `ne_type_id`, `ne_type_name`, `ipaddress`, 
`res_type_name`, 
`res_url`, 
`res_name`, `alarm_type_id`, `alarm_type_name`, `alarm_type_label`, `alarm_level`, `alarm_event_type`, 
`is_affect_service`, `alarm_category`, `alarm_cause_id`, `alarm_group`, `report_time`,
 `latest_time`, `ne_time`, `lasting_time`, `ack_time`, `ack_user`, `ack_host`, `ack_log`, 
 `clear_time`, `clear_user`, `clear_host`, `clear_log`, `isclr`, `isack`, `trap_msg`, `alarm_remark`,`c_date`)  
 select  
 alarmId, OltId, '', null, null,  '', 
 CASE ponifid WHEN 0 THEN 'ne' ELSE 'port' END, 
 CASE ponifid WHEN 0 THEN	concat('/ne=', oltid) ELSE concat('/ne=',	oltid, '/shelf=1/slot=', slotid, '/port=',ponifid) END,
  alarmSourceName,  AlarmType, alarm_type_name, alarm_type_label, case AlarmLevel when 1 then 5 when 2 then 3 when 3 then 2 else AlarmLevel end, '2', 
 '0', '1', 'unidentified', NULL, DATE_ADD('1970-1-1',INTERVAL GenTime+28800 SECOND) , 
 DATE_ADD('1970-1-1',INTERVAL GenTime+28800 SECOND), '', '0', AffirmTime, UserIdAffirmer, '', '', 
 DATE_ADD('1970-1-1',INTERVAL ClearTime+28800 SECOND), userIdClear, '', ReasonForClear, '0', AffirmState, '', '',date_format(NOW(),'%Y-%m-%d') 
 from `ems`.alarmmgrrm,`ems_h`.alarm_type t2
  where AlarmType=t2.alarm_type_id;

end;
