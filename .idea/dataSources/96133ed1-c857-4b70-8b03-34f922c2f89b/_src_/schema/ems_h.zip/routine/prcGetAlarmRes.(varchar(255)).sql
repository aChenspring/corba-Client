CREATE PROCEDURE prcGetAlarmRes(IN  URL    VARCHAR(255), OUT ResType VARCHAR(50), OUT ResID VARCHAR(255),
                                OUT PResID VARCHAR(255))
  BEGIN
	declare pindex   integer default 0;

  set ResID = URL;
  if instr(URL,'/ctp')>0 then
  	set ResType = 'PORT_CTP';
  	set pindex=instr(URL,'/ctp');
  elseif instr(URL,'/port')>0 then
    set ResType='PORT';
    set ResID = SUBSTRING_INDEX(URL,'/',6);  
    set pindex=instr(URL,'/port'); 
  elseif instr(URL,'/card')>0 then
    set ResType='CARD';
    set ResID = SUBSTRING_INDEX(URL,'/',5); 
    set pindex=instr(URL,'/card');
  elseif instr(URL,'/slot')>0 then
    set ResType='SLOT';
    set ResID = SUBSTRING_INDEX(URL,'/',4);
    set pindex=instr(URL,'/slot'); 
  elseif instr(URL,'/shelf')>0 then
    set ResType='CHASSIS';
    set ResID = SUBSTRING_INDEX(URL,'/',3);
    set pindex=instr(URL,'/shelf'); 
  elseif instr(URL,'/ne')>0 then
    set ResType='NE';
    set ResID = replace(URL,'/ne=','');
  else
    set ResType='';
    set ResID='';
  end if;                 
  if pindex > 1 then
      set PResID = left(URL,pindex-1);
  else
      set PResID = '';
  end if;
END;
