CREATE FUNCTION ArrayIndex(ArrayString TEXT, Spliter CHAR, OneString VARCHAR(200))
  RETURNS SMALLINT(6)
  BEGIN
    declare i	int default 0;
    declare iArrayCount int;
    set iArrayCount = ArrayCount(ArrayString,Spliter);
    while i<= iArrayCount Do
    	if OneString = ArraySplit(ArrayString,Spliter,i) then
           return i;
        end if;
        set i = i+1;
    end while; 
    return 0;
END;
