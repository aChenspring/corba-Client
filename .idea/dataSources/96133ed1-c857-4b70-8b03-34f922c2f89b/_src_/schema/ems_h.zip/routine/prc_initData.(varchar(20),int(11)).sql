CREATE PROCEDURE prc_initData(IN vDate VARCHAR(20), INOUT errorcode INT)
  begin
  declare continue HANDLER FOR SQLEXCEPTION set errorcode = -1;
  set errorcode=0;
  
    
    call prc_clearData(errorcode);

     insert INTO `ems_h`.`topo_mainview_symbol` 
 (`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`) 
  select 
  `symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`
  from `ems_h`.topo_mainview_symbol_h
  where c_date=vDate AND  res_type_name='SUBNET';


  insert INTO `ems_h`.`ne` 
(`subnet_id`, `ne_id`, `ne_type_id`, `ne_name`, `ne_friendly_name`,
 `software_ver`, `hardware_ver`, `ipaddress`, `macaddress`, `subnet_mask`, 
`snmp_port`, `snmp_readcommon`, `snmp_writecommon`, `snmp_v3_para`, `snmp_version`, `snmp_retry`, `snmp_timeout`, 
`login_user`, `login_password`, `create_user`, `create_time`, `update_user`, `update_time`, 
`init_status`, `syn_status`, `last_syn_time`, `syn_end_time`, `syn_remark`, `hierarchy`, `remark`, 
`online_status`, `latitude`, `longitude`, `emscontainer_id`)  
  select  
`subnet_id`, `ne_id`, `ne_type_id`, `ne_name`, `ne_friendly_name`,
 `software_ver`, `hardware_ver`, `ipaddress`, `macaddress`, `subnet_mask`, 
`snmp_port`, `snmp_readcommon`, `snmp_writecommon`, `snmp_v3_para`, `snmp_version`, `snmp_retry`, `snmp_timeout`, 
`login_user`, `login_password`, `create_user`, `create_time`, `update_user`, `update_time`, 
`init_status`, `syn_status`, `last_syn_time`, `syn_end_time`, `syn_remark`, `hierarchy`, `remark`, 
`online_status`, `latitude`, `longitude`, `emscontainer_id`
  from `ems_h`.ne_h
  where c_date=vDate;

     insert INTO `ems_h`.`topo_mainview_symbol` 
 (`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`) 
  select 
  `symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`
  from `ems_h`.topo_mainview_symbol_h
  where c_date=vDate AND  res_type_name<>'SUBNET';


    insert INTO `ems_h`.`link` 
(`LINK_ID`, `LINK_NAME`, `FRIENDLY_NAME`, 
`SRC_PORT_ID`, `SRC_PORT_TYPE`, `DES_PORT_ID`, `DES_PORT_TYPE`,
 `LINE_RATE`, `LINE_LENGTH`, `TRAN_MODEL`, 
 `SRC_IRCNETNODEID`,`SRC_RES_TYPE`, `SRC_ID`, `DES_IRCNETNODEID`, `DES_RES_TYPE`, `DES_ID`,
 `REMARK`, `IS_PROTECTED`, `RATE_TIMES`, `LINK_TYPE_ID`, `LINK_DIRECTION`, `ATTENUATION`, 
`INDEX_IN_MIB`, `LINK_STATE`, `ACTIVE_STATE`, `CREATE_USER`, `CREATE_TIME`, 
`MAINTENANCE_PERSON_ID`, `TOPO_TYPE_ID`, `CREATE_TYPE`, `LINK_URL`, `ISLINK_AUTO_DISCOVER`) 
select  
 `LINK_ID`, `LINK_NAME`, `FRIENDLY_NAME`, 
 `SRC_PORT_ID`, `SRC_PORT_TYPE`, `DES_PORT_ID`, `DES_PORT_TYPE`,
 `LINE_RATE`, `LINE_LENGTH`, `TRAN_MODEL`, 
 `SRC_IRCNETNODEID`,`SRC_RES_TYPE`, `SRC_ID`, `DES_IRCNETNODEID`, `DES_RES_TYPE`, `DES_ID`,
 `REMARK`, `IS_PROTECTED`, `RATE_TIMES`, `LINK_TYPE_ID`, `LINK_DIRECTION`, `ATTENUATION`, 
`INDEX_IN_MIB`, `LINK_STATE`, `ACTIVE_STATE`, `CREATE_USER`, `CREATE_TIME`, 
`MAINTENANCE_PERSON_ID`, `TOPO_TYPE_ID`, `CREATE_TYPE`, `LINK_URL`, `ISLINK_AUTO_DISCOVER`
  from `ems_h`.link_h
  where c_date=vDate;

   insert INTO `ems_h`.`topo_mainview_link_symbol` (
 `LINK_SYMBOL_ID`, `MAIN_VIEW_ID`, 
 `RES_ID`, `RES_TYPE_NAME`, `SRC_SYMBOL_ID`, `DEST_SYMBOL_ID`, 
 `LINK_NAME`, `REMARK`, `DIRECTION`, `COLOR`, `COLOR_RGB`, `WIDTH`, `STYLE`, `SHAPE`, `STATUS_COMMUNICATION`, `STATUS_WORKING`,
 `TOPO_TYPE_ID`, `SRC_MAP_HIERARCHY`, `DES_MAP_HIERARCHY`, `SUBNET_ID`, `SRC_PORT_TYPE`, 
 `SRC_PORT_ID`, `DES_PORT_TYPE`, `DES_PORT_ID`) 
  select 
  LINK_ID, '1', 
  LINK_ID, 'TOPO_MAINVIEW_LINK_SYMBOL', t1.symbol_id, t2.symbol_id, 
  '', '', '2', '0', NULL, '2', '0', '0', '0', '0', 
  '4_2', t1.map_hierarchy, t2.map_hierarchy, t1.map_parent_id, 
  'port', t.SRC_PORT_ID, 'port', t.DES_PORT_ID
  from `ems_h`.link t,`ems_h`.topo_mainview_symbol t1,`ems_h`.topo_mainview_symbol t2
   where t.SRC_IRCNETNODEID=t1.ne_id and t.DES_IRCNETNODEID=t2.ne_id;


  insert INTO `ems_h`.`alarm` 
(`alarm_id`, `ne_id`, `ne_name`, `ne_type_id`, `ne_type_name`, `ipaddress`, 
`res_type_name`, 
`res_url`, 
`res_name`, `alarm_type_id`, `alarm_type_name`, `alarm_type_label`, `alarm_level`, `alarm_event_type`, 
`is_affect_service`, `alarm_category`, `alarm_cause_id`, `alarm_group`, `report_time`,
 `latest_time`, `ne_time`, `lasting_time`, `ack_time`, `ack_user`, `ack_host`, `ack_log`, 
 `clear_time`, `clear_user`, `clear_host`, `clear_log`, `isclr`, `isack`, `trap_msg`, `alarm_remark`) 
 select  
`alarm_id`, `ne_id`, `ne_name`, `ne_type_id`, `ne_type_name`, `ipaddress`, 
`res_type_name`, 
`res_url`, 
`res_name`, `alarm_type_id`, `alarm_type_name`, `alarm_type_label`, `alarm_level`, `alarm_event_type`, 
`is_affect_service`, `alarm_category`, `alarm_cause_id`, `alarm_group`, `report_time`,
 `latest_time`, `ne_time`, `lasting_time`, `ack_time`, `ack_user`, `ack_host`, `ack_log`, 
 `clear_time`, `clear_user`, `clear_host`, `clear_log`, `isclr`, `isack`, `trap_msg`, `alarm_remark`
  from `ems_h`.alarm_h
  where c_date=vDate and Clear_Time='1970-01-01 08:00:00';
  
end;
