CREATE FUNCTION ArraySplit(ArrayString TEXT, Spliter CHAR, ArrayIndex INT)
  RETURNS TEXT
  BEGIN
    declare iStart int;
    declare iEnd   int;
    declare vArrayString text;
    if ArrayString is null then
    	return '';
    end if;
    if TRIM(ArrayString) is null then
    	return '';
    end if;
    set vArrayString = concat(Spliter,ArrayString,Spliter);
    RETURN SUBSTRING_INDEX(SUBSTRING_INDEX(vArrayString,Spliter,ArrayIndex+1),Spliter,-1);
END;
