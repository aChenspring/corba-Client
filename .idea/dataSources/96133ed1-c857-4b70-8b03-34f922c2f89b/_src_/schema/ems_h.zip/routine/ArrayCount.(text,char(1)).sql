CREATE FUNCTION ArrayCount(ArrayString TEXT, Spliter CHAR)
  RETURNS INT
  BEGIN
  RETURN length(ArrayString)-length(replace(ArrayString,Spliter,''))+1;
END;
