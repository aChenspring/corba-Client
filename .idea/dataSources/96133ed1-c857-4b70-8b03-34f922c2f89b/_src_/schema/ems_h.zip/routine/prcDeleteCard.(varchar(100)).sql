CREATE PROCEDURE prcDeleteCard(IN CardID VARCHAR(100))
  BEGIN
	declare isExist,iC int default 0; 
	declare vtablename varchar(200);
	declare vsql       varchar(2000);
  
  declare rs cursor for select distinct TABLE_NAMES FROM res_type_cfg where TABLE_NAMES like 'PMDATA_%';
  declare CONTINUE HANDLER FOR NOT FOUND SET isExist = 1; 
	
	
	
	delete from alarm where res_url=CardID or res_url like concat(CardID,'/%');
	delete from alarm_his where res_url=CardID or res_url like concat(CardID,'/%');

	  open rs;
    fetch rs into vtablename;
    while(isExist = 0) do 
      set vsql = concat('delete from ',vtablename ,' where card_id = ',CardID);
      call exeSql(vsql,iC);
      fetch rs into vtablename;
    end while;
    close rs;

	
	delete from pm_task_detail where res_id=CardID or res_id like concat(CardID,'/%');
	
	
	delete from link where SRC_PORT_ID like concat(CardID,'/%') or DES_PORT_ID like concat(CardID,'/%');
	
	
	delete from port where card_id = CardID;
	
END;
