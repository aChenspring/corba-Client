CREATE TRIGGER td_a_odnlinkrm
AFTER DELETE ON odnlinkrm
FOR EACH ROW
  begin
  declare vResChangeID int;
	
	
 
 		 insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('topo_mainview_link_symbol','topo_mainview_link_symbol','LINK_SYMBOL_ID',old.odnLinkId,concat(old.EastPortName,'---',old.WestPortName),'删除链路',2,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();
		        
 insert INTO `ems_h`.`topo_mainview_link_symbol_log` (
 `id`,`oper_type`,
 `LINK_SYMBOL_ID`, `MAIN_VIEW_ID`, 
 `RES_ID`, `RES_TYPE_NAME`, `SRC_SYMBOL_ID`, `DEST_SYMBOL_ID`, 
 `LINK_NAME`, `REMARK`, 
 `DIRECTION`, `COLOR`, `COLOR_RGB`, `WIDTH`, `STYLE`, `SHAPE`, `STATUS_COMMUNICATION`, `STATUS_WORKING`, `TOPO_TYPE_ID`, 
 `SRC_MAP_HIERARCHY`, 
 `DES_MAP_HIERARCHY`, 
 `SUBNET_ID`, 
 `SRC_PORT_TYPE`,  `SRC_PORT_ID`, 
 `DES_PORT_TYPE`, `DES_PORT_ID`) 
 select 
  vResChangeID,2,
  old.odnLinkId, '1', 
  old.odnLinkId, 'TOPO_MAINVIEW_LINK_SYMBOL', 500000+arraysplit(old.EastPortDn,':',6), 500000+arraysplit(old.WestPortDn,':',6), 
  concat(old.EastPortName,'---',old.WestPortName),concat(t1.name,'-',t2.name), 
  '2', '0', NULL, '2', '0', '0', '0', '0',   '4_2', 
  concat(',0',t1.subnetIdList,500000+arraysplit(old.EastPortDn,':',6),','), 
  concat(',0',t1.subnetIdList,500000+arraysplit(old.WestPortDn,':',6),','), 
  SUBSTRING_INDEX(SUBSTRING_INDEX(concat(',0',t1.subnetIdList),',',-2),',',1), 
  'port', replace(replace(replace(old.EastPortDn,'CF::FSAP::OLTEquipRM:','/ne='),':SubrackRM:1:SlotRM:','/shelf=1/slot='),':PhyPortRM:','/port='), 
  'port', replace(replace(replace(old.WestPortDn,'CF::FSAP::OLTEquipRM:','/ne='),':SubrackRM:1:SlotRM:','/shelf=1/slot='),':PhyPortRM:','/port=')
  from oltequiprm t1,oltequiprm t2
   where SUBSTRING_INDEX(old.EastPortDn,':SubrackRM:',1)=t1.dn and SUBSTRING_INDEX(old.WestPortDn,':SubrackRM:',1)=t2.dn;
 
end;
