CREATE TRIGGER tu_a_alarmmgrrm
AFTER UPDATE ON alarmmgrrm
FOR EACH ROW
  begin
	declare vResChangeID int;
	
    if ifnull(old.AffirmState,'')<>ifnull(new.AffirmState,'') then
		  insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('alarm','alarm','alarm_id',new.alarmId,new.alarmId,'',3,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();
		   
		  insert into `ems_h`.res_log_property (RES_CHANGE_ID,CHANGE_PROPERTY_FIELD,NEW_VALUE,OLD_VALUE,CHANGE_TIME)
		          values(vResChangeID,'isack',new.AffirmState,old.AffirmState,date_format(NOW(),'%Y-%m-%d %T'));
    end if;
     
    if ifnull(old.ClearTime,'')<>ifnull(new.ClearTime,'') then
		  insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('alarm','alarm','alarm_id',new.alarmId,new.alarmId,'',2,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();
		   
    insert INTO `ems_h`.`alarm_log` 
    (`id`,`oper_type`,`alarm_id`, `ne_id`, `ne_name`, `ne_type_id`, `ne_type_name`, `ipaddress`, 
     `res_type_name`, 
     `res_url`, 
     `res_name`, 
     `alarm_type_id`, `alarm_type_name`, `alarm_type_label`, `alarm_level`, `alarm_event_type`, 
     `is_affect_service`, `alarm_category`, `alarm_cause_id`, `alarm_group`, `report_time`,
     `latest_time`, `ne_time`, `lasting_time`, `ack_time`, `ack_user`, `ack_host`, `ack_log`, 
     `clear_time`, `clear_user`, `clear_host`, `clear_log`, `isclr`, `isack`, `trap_msg`, `alarm_remark`,`c_date`)
   select  
     vResChangeID,2,old.alarmId, old.OltId, n.ne_name, n.ne_type_id, t.ne_type_name,  n.ipaddress, 
     CASE old.ponifid WHEN 0 THEN 'ne' ELSE 'port' END, 
     CASE old.ponifid WHEN 0 THEN	concat('/ne=', old.OltId) ELSE concat('/ne=',	old.OltId, '/shelf=1/slot=', old.slotid, '/port=',old.ponifid) END,
     old.alarmSourceName,  
     old.AlarmType, a.alarm_type_name, a.alarm_type_label, case old.AlarmLevel when 1 then 5 when 2 then 3 when 3 then 2 else old.AlarmLevel end, '2', 
     '0', '1', 'unidentified', NULL, DATE_ADD('1970-1-1',INTERVAL old.GenTime+28800 SECOND) , 
     DATE_ADD('1970-1-1',INTERVAL old.GenTime+28800 SECOND), '', '0', old.AffirmTime, old.UserIdAffirmer, '', '', 
     DATE_ADD('1970-1-1',INTERVAL old.ClearTime+28800 SECOND), old.userIdClear, '', old.ReasonForClear, '1', old.AffirmState, old.autoID, '',date_format(NOW(),'%Y-%m-%d %T')
   from oltequiprm n,`ems_h`.alarm_type a,`ems_h`.ne_type t
 where n.deviceType=t.ne_type_id and new.AlarmType=a.alarm_type_id
  and n.dn =concat('CF::FSAP::OLTEquipRM:',new.OltId);
     
    end if;  
    
    
end;
