CREATE TRIGGER neDelete_trigger
BEFORE DELETE ON oltequiprm
FOR EACH ROW
  BEGIN
  DELETE FROM nemonitortask WHERE neName = OLD.dn;
END;
