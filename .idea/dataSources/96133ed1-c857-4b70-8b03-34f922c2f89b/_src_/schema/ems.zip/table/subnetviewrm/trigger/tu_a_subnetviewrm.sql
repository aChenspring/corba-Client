CREATE TRIGGER tu_a_subnetviewrm
AFTER UPDATE ON subnetviewrm
FOR EACH ROW
  begin
  declare vResChangeID int;
	declare vsubnetName varchar(200);
	declare vdescription varchar(200);
	
   if instr(old.dn,'CF::FSAP::UserViewRM:32001:')>0 then
	   select subnetName,description into vsubnetName,vdescription from subnetrm where dn=new.aimDn;
   
   
		
		  insert into `ems_h`.res_log_total (RES_TYPE_TABLE,RES_TYPE,RES_PK_FIELDS,RES_IDS,LOG_RES_NAME,LOG_REMARK,CHANGE_TYPE,CHANGE_TIME)
		          values('topo_mainview_symbol','subnet','symbol_id',SUBSTRING_INDEX(old.aimDn,':',-1),vsubnetName,'子网移动位置',3,date_format(NOW(),'%Y-%m-%d %T'));
		        set vResChangeID = LAST_INSERT_ID();

		  if ifnull(old.x_dimension,'')<>ifnull(new.x_dimension,'') then
		           insert into `ems_h`.res_log_property (RES_CHANGE_ID,CHANGE_PROPERTY_FIELD,NEW_VALUE,OLD_VALUE,CHANGE_TIME)
		              values(vResChangeID,'x',new.x_dimension,old.x_dimension,date_format(NOW(),'%Y-%m-%d %T'));
		  end if;
		  
		  if ifnull(old.y_dimension,'')<>ifnull(new.y_dimension,'') then
		           insert into `ems_h`.res_log_property (RES_CHANGE_ID,CHANGE_PROPERTY_FIELD,NEW_VALUE,OLD_VALUE,CHANGE_TIME)
		              values(vResChangeID,'y',new.y_dimension,old.y_dimension,date_format(NOW(),'%Y-%m-%d %T'));
		  end if;
		  
     insert INTO `ems_h`.`topo_mainview_symbol_log` 
 (`id`,`oper_type`,`symbol_id`, `symbol_name`, `main_view_id`, `res_type_name`, `res_id`, 
  `ne_id`, `map_parent_id`, `tree_parent_id`, `symbol_style`, `layout`, 
  `expandable`, `lockable`, `is_locked`, `x`, `y`, 
  `status_online`, `status_sync`, `status_config_sync`, `status_performance`, `status_alarm_filter`, `status_con_customer`, 
  `map_hierarchy`, `topo_type_id`, `tree_layout_root`, `ne_parent_id`, `is_visible`, 
  `topo_orderby_number`, `create_user`, `remark`,`c_date`) 
  VALUES 
   (vResChangeID,3,SUBSTRING_INDEX(new.aimDn,':',-1), vsubnetName, '1', 'SUBNET', SUBSTRING_INDEX(new.aimDn,':',-1), 
   NULL, '0', '0', '2', '0',
  '1', '1', '0', new.x_dimension, new.y_dimension, 
   '1', '2', '2', '0', '0', '0',
   concat(',0',SUBSTRING_INDEX(new.aimDn,':',-1),','), '1_1_1', NULL, '0', '1',
      NULL, 'admin', vdescription,date_format(NOW(),'%Y-%m-%d %T'));
		  
   end if;
end;
