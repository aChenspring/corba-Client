CREATE PROCEDURE Proc_InsertFluxData(IN m_ifin       BIGINT, IN m_ifinu BIGINT, IN m_ifinnu BIGINT, IN m_ifine BIGINT,
                                     IN m_ifou       BIGINT, IN m_ifoutu BIGINT, IN m_ifoutnu BIGINT,
                                     IN m_ifoute     BIGINT, IN m_indexvalue INT, IN m_oltid INT)
  BEGIN
	declare counts int;
	declare mm_ifin bigint;
	declare mm_ifinu  bigint;
	declare mm_ifinnu bigint;
	declare mm_ifine  bigint;
	declare mm_ifou  bigint;
	declare mm_ifoutu  bigint;
	declare mm_ifoutnu  bigint;
	declare mm_ifoute  bigint;
	insert dailydata (ifinoctets,ifinucastpkts,ifinnucastpkts,ifinerrors,ifoutoctets,ifoutucastpkts,ifoutnucastpkts,ifouterrors,indexvalue,oltid) 
	values(m_ifin,m_ifinu,m_ifinnu,m_ifine,m_ifou,m_ifoutu,m_ifoutnu,m_ifoute,m_indexvalue,m_oltid);
	
	
	select count(*) into counts  from dailydata where indexvalue=m_indexvalue and oltid=m_oltid;
	IF counts = 24 then
		select sum(ifinoctets) into mm_ifin from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifinucastpkts) into mm_ifinu from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifinnucastpkts) into mm_ifinnu from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifinerrors) into mm_ifine from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifoutoctets) into mm_ifou from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifoutucastpkts) into mm_ifoutu from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifoutnucastpkts) into mm_ifoutnu from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		select sum(ifouterrors) into mm_ifoute from (select  * from dailydata where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,12 ) as t1;
		insert weekly(ifinoctets,ifinucastpkts,ifinnucastpkts,ifinerrors,ifoutoctets,ifoutucastpkts,ifoutnucastpkts,ifouterrors,indexvalue,oltid) 
		values(mm_ifin,mm_ifinu,mm_ifinnu,mm_ifine,mm_ifou,mm_ifoutu,mm_ifoutnu,mm_ifoute,m_indexvalue,m_oltid);		
		delete from dailydata  where indexvalue=m_indexvalue and oltid=m_oltid order by id limit 12;
		select count(*) into counts  from weekly where indexvalue=m_indexvalue and oltid=m_oltid;
		IF counts = 14 then
			select sum(ifinoctets) into mm_ifin from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifinucastpkts) into mm_ifinu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifinnucastpkts) into mm_ifinnu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifinerrors) into mm_ifine from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifoutoctets) into mm_ifou from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifoutucastpkts) into mm_ifoutu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifoutnucastpkts) into mm_ifoutnu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			select sum(ifouterrors) into mm_ifoute from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,7 ) as t1;
			insert monthdata(ifinoctets,ifinucastpkts,ifinnucastpkts,ifinerrors,ifoutoctets,ifoutucastpkts,ifoutnucastpkts,ifouterrors,indexvalue,oltid) 
			values(mm_ifin,mm_ifinu,mm_ifinnu,mm_ifine,mm_ifou,mm_ifoutu,mm_ifoutnu,mm_ifoute,m_indexvalue,m_oltid);		
			delete from weekly  where indexvalue=m_indexvalue and oltid=m_oltid order by id limit 4;
                        select count(*) into counts  from monthdata where indexvalue=m_indexvalue and oltid=m_oltid;
		IF counts = 8 then
			select sum(ifinoctets) into mm_ifin from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4) as t1;
			select sum(ifinucastpkts) into mm_ifinu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			select sum(ifinnucastpkts) into mm_ifinnu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			select sum(ifinerrors) into mm_ifine from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			select sum(ifoutoctets) into mm_ifou from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			select sum(ifoutucastpkts) into mm_ifoutu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			select sum(ifoutnucastpkts) into mm_ifoutnu from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			select sum(ifouterrors) into mm_ifoute from (select  * from weekly where  indexvalue=m_indexvalue and oltid=m_oltid order by id desc limit 0,4 ) as t1;
			insert year(ifinoctets,ifinucastpkts,ifinnucastpkts,ifinerrors,ifoutoctets,ifoutucastpkts,ifoutnucastpkts,ifouterrors,indexvalue,oltid) 
			values(mm_ifin,mm_ifinu,mm_ifinnu,mm_ifine,mm_ifou,mm_ifoutu,mm_ifoutnu,mm_ifoute,m_indexvalue,m_oltid);		
			delete from weekly  where indexvalue=m_indexvalue and oltid=m_oltid order by id limit 4;
		END IF;
		END IF;
                
            
	END IF;
END;
